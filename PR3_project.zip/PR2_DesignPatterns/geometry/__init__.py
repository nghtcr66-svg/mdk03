# geometry/__init__.py
from .shapes import Shape, Circle, Rectangle, Triangle
from .factory import ShapeFactory

__all__ = ["Shape", "Circle", "Rectangle", "Triangle", "ShapeFactory"]

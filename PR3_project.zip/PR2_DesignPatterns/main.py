# main.py
from geometry import ShapeFactory


def main():
    factory = ShapeFactory()

    shapes = [
        factory.create_shape("circle", radius=5.0),
        factory.create_shape("rectangle", width=4.0, height=6.0),
        factory.create_shape("triangle", a=3.0, b=4.0, c=5.0),
    ]

    print("=== РЕЗУЛЬТАТ РАБОТЫ МОДУЛЬНОГО ПРИЛОЖЕНИЯ ===")
    for shape in shapes:
        class_name = shape.__class__.__name__
        print(f"Фигура: {class_name:<12} | Площадь: {shape.get_area():.2f} | Периметр: {shape.get_perimeter():.2f}")


if __name__ == "__main__":
    main()

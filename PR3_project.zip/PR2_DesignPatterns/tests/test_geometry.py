# tests/test_geometry.py
import unittest
from geometry import Circle, Rectangle, Triangle, ShapeFactory


class TestGeometry(unittest.TestCase):
    """Набор модульных тестов для пакета geometry."""

    def test_circle_calculations(self):
        """Проверка расчетов площади и периметра круга."""
        circle = Circle(5.0)
        self.assertAlmostEqual(circle.get_area(), 78.54, places=2)
        self.assertAlmostEqual(circle.get_perimeter(), 31.42, places=2)

    def test_rectangle_calculations(self):
        """Проверка расчетов площади и периметра прямоугольника."""
        rect = Rectangle(4.0, 6.0)
        self.assertAlmostEqual(rect.get_area(), 24.00, places=2)
        self.assertAlmostEqual(rect.get_perimeter(), 20.00, places=2)

    def test_triangle_calculations(self):
        """Проверка расчетов треугольника по формуле Герона."""
        triangle = Triangle(3.0, 4.0, 5.0)
        self.assertAlmostEqual(triangle.get_perimeter(), 12.00, places=2)
        self.assertAlmostEqual(triangle.get_area(), 6.00, places=2)

    def test_factory_creation(self):
        """Проверка корректности создания классов через фабрику."""
        factory = ShapeFactory()
        c = factory.create_shape("circle", radius=10.0)
        r = factory.create_shape("rectangle", width=3.0, height=8.0)
        t = factory.create_shape("triangle", a=5.0, b=5.0, c=6.0)
        self.assertIsInstance(c, Circle)
        self.assertIsInstance(r, Rectangle)
        self.assertIsInstance(t, Triangle)

    def test_validation_errors(self):
        """Проверка возбуждения исключений при передаче невалидных параметров."""
        with self.assertRaises(ValueError):
            Circle(-2.0)
        with self.assertRaises(ValueError):
            Rectangle(0, 10.0)
        with self.assertRaises(ValueError):
            Triangle(1.0, 2.0, 10.0)

    def test_factory_invalid_inputs(self):
        """Проверка реакции фабрики на неполные аргументы или неизвестный тип."""
        factory = ShapeFactory()
        with self.assertRaises(ValueError):
            factory.create_shape("ellipse", radius=5.0)
        with self.assertRaises(ValueError):
            factory.create_shape("rectangle", width=5.0)


if __name__ == "__main__":
    unittest.main()

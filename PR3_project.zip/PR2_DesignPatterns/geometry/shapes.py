# geometry/shapes.py
from abc import ABC, abstractmethod
import math


class Shape(ABC):
    """Абстрактный базовый класс геометрической фигуры."""

    @abstractmethod
    def get_area(self) -> float:
        """Расчет площади фигуры."""
        pass

    @abstractmethod
    def get_perimeter(self) -> float:
        """Расчет периметра фигуры."""
        pass


class Circle(Shape):
    """Класс фигуры: Круг."""

    def __init__(self, radius: float):
        if radius <= 0:
            raise ValueError("Радиус круга должен быть строго больше нуля.")
        self.radius = float(radius)

    def get_area(self) -> float:
        return math.pi * (self.radius ** 2)

    def get_perimeter(self) -> float:
        return 2 * math.pi * self.radius


class Rectangle(Shape):
    """Класс фигуры: Прямоугольник."""

    def __init__(self, width: float, height: float):
        if width <= 0 or height <= 0:
            raise ValueError("Стороны прямоугольника должны быть строго больше нуля.")
        self.width = float(width)
        self.height = float(height)

    def get_area(self) -> float:
        return self.width * self.height

    def get_perimeter(self) -> float:
        return 2 * (self.width + self.height)


class Triangle(Shape):
    """Класс фигуры: Треугольник."""

    def __init__(self, a: float, b: float, c: float):
        if a <= 0 or b <= 0 or c <= 0:
            raise ValueError("Стороны треугольника должны быть строго больше нуля.")
        if (a + b <= c) or (a + c <= b) or (b + c <= a):
            raise ValueError("Нарушено неравенство треугольника: сумма любых двух сторон должна быть больше третьей.")
        self.a = float(a)
        self.b = float(b)
        self.c = float(c)

    def get_perimeter(self) -> float:
        return self.a + self.b + self.c

    def get_area(self) -> float:
        p = self.get_perimeter() / 2.0
        return math.sqrt(p * (p - self.a) * (p - self.b) * (p - self.c))

# geometry/factory.py
from typing import Any
from .shapes import Shape, Circle, Rectangle, Triangle


class ShapeFactory:
    """Фабрика для создания объектов геометрических фигур."""

    @staticmethod
    def create_shape(shape_type: str, **kwargs: Any) -> Shape:
        normalized_type = shape_type.strip().lower()

        if normalized_type == 'circle':
            radius = kwargs.get('radius')
            if radius is None:
                raise ValueError("Для создания круга обязателен именованный аргумент 'radius'.")
            return Circle(radius)

        elif normalized_type == 'rectangle':
            width = kwargs.get('width')
            height = kwargs.get('height')
            if width is None or height is None:
                raise ValueError("Для создания прямоугольника обязательны аргументы 'width' и 'height'.")
            return Rectangle(width, height)

        elif normalized_type == 'triangle':
            a = kwargs.get('a')
            b = kwargs.get('b')
            c = kwargs.get('c')
            if a is None or b is None or c is None:
                raise ValueError("Для создания треугольника обязательны аргументы 'a', 'b' и 'c'.")
            return Triangle(a, b, c)

        else:
            raise ValueError(f"Неизвестный тип геометрической фигуры: '{shape_type}'.")
